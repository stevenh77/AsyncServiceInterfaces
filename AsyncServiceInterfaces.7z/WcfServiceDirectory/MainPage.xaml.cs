﻿using DTOs;
namespace WcfServiceDirectory
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            //var services = new Services();
            //var request = new GetLoginRequest();
            //services.OperatorFacade.GetOperator.Execute(request, OnGetOperatorComplete);
        }

        private void OnGetOperatorComplete(CallCompleteEventArgs<GetLoginResponse> e)
        {
            if (e.Error == null && e.Result != null)
            {
                //success

            }
            else
            {
                //failed
            }
        }
    }
}
