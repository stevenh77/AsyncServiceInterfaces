﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DTOs
{
    public class GetLoginRequest { public string Payload { get; set; } }
    public class GetLoginResponse { public string Payload { get; set; } }
    public class UpdateLoginRequest { public string Payload { get; set; } }
    public class UpdateLoginResponse { public string Payload { get; set; } }
}