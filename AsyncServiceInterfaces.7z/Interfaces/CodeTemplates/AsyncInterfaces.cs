 
 
 
 
using DTOs;
using Newtonsoft.Json;
using System;

namespace WcfServiceDirectory
{
	public class Services
    {
		public test test { get; set; }
	}
    
    
	public class test
	{
    
    }
}